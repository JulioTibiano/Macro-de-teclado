
package parte1;


public interface Timer {
    public int DELAY = 1000;
    public boolean verifica();
    public void decrementaTempo();
}
