package parte1;


public interface Utilizavel extends Timer{
    public boolean isReady();
    public void usa();
}
